import Order from './order.model.js';
import { getIO } from '../../socket/io.js';
import { EVENTS, ROOMS } from '../../socket/events.js';
import {
  createOrder as svcCreate,
  addItemsToOrder,
  transitionStatus,
  generateKOT,
  generateBill,
  checkout as svcCheckout,
  updateItemStatus as svcUpdateItemStatus,
} from './order.service.js';

// ─── Queries ──────────────────────────────────────────────────────────────────

export const getOrders = async (req, res) => {
  const { status, tableId, from, to, page = 1, limit = 30 } = req.query;
  const filter = { ...req.branchFilter }; // always scoped to restaurant+branch
  if (status) filter.status = status;
  if (tableId) filter.table = tableId;
  if (from || to) {
    filter.createdAt = {};
    if (from) filter.createdAt.$gte = new Date(from);
    if (to) filter.createdAt.$lte = new Date(to);
  }

  const skip = (page - 1) * limit;
  const [orders, total] = await Promise.all([
    Order.find(filter)
      .populate('table', 'number location')
      .populate('waiter', 'name')
      .sort('-createdAt')
      .skip(skip)
      .limit(Number(limit)),
    Order.countDocuments(filter),
  ]);

  res.json({ total, page: Number(page), pages: Math.ceil(total / limit), orders });
};

export const getOrder = async (req, res) => {
  const order = await Order.findOne({ _id: req.params.id, ...req.tenantFilter })
    .populate('table', 'number capacity location')
    .populate('waiter', 'name email role')
    .populate('items.menuItem', 'name category price')
    .populate('statusHistory.changedBy', 'name role');
  if (!order) return res.status(404).json({ message: 'Order not found' });
  res.json(order);
};

/**
 * GET /api/orders/kitchen
 * Active orders for the kitchen display (confirmed + preparing + ready).
 */
export const getKitchenOrders = async (req, res) => {
  const orders = await Order.find({
    ...req.branchFilter,
    $or: [
      { status: { $in: ['confirmed', 'preparing', 'ready'] } },
      { status: 'pending', source: 'customer_qr' },
    ],
  })
    .populate('table', 'number location')
    .populate('waiter', 'name')
    .sort('createdAt');
  res.json(orders);
};

// ─── POS: create ─────────────────────────────────────────────────────────────

export const createOrder = async (req, res) => {
  const { table, items, notes, taxRate } = req.body;
  const order = await svcCreate({
    tableId: table,
    itemInputs: items,
    notes,
    taxRate,
    userId: req.user._id,
    restaurantId: req.restaurantId,
    branchId: req.branchId,
  });
  res.status(201).json(order);
};

export const addItems = async (req, res) => {
  const order = await addItemsToOrder(req.params.id, req.body.items, req.user._id);
  res.json(order);
};

// ─── Status ───────────────────────────────────────────────────────────────────

export const updateOrderStatus = async (req, res) => {
  const { status, note } = req.body;
  const order = await transitionStatus(req.params.id, status, req.user._id, note);
  res.json({ order });
};

// ─── KOT ─────────────────────────────────────────────────────────────────────

export const printKOT = async (req, res) => {
  const kot = await generateKOT(req.params.id, req.user._id);
  res.json(kot);
};

// ─── Bill ─────────────────────────────────────────────────────────────────────

export const getBill = async (req, res) => {
  const { discountType, discountValue } = req.query;
  const bill = await generateBill(req.params.id, {
    discountType,
    discountValue: discountValue ? Number(discountValue) : 0,
  });
  res.json(bill);
};

export const markBillPresented = async (req, res) => {
  const order = await Order.findOneAndUpdate(
    { _id: req.params.id, ...req.tenantFilter },
    { billStatus: 'presented', billGeneratedAt: new Date() },
    { new: true }
  )
    .populate('table', 'number location')
    .populate('waiter', 'name');

  if (!order) return res.status(404).json({ message: 'Order not found' });

  const payload = {
    orderId: order._id,
    orderNumber: order.orderNumber,
    tableNumber: order.table?.number,
    billStatus: order.billStatus,
    message: `Bill presented for Table ${order.table?.number || '?'}`,
    createdAt: new Date(),
  };

  const io = getIO();
  if (io) {
    io.to(ROOMS.order(order._id)).emit(EVENTS.BILL_PRESENTED, payload);
    io.to(ROOMS.pos).emit(EVENTS.BILL_PRESENTED, payload);
    io.to(ROOMS.kitchen).emit(EVENTS.BILL_PRESENTED, payload);
  }

  res.json({ order });
};

// ─── Checkout ─────────────────────────────────────────────────────────────────

export const checkoutOrder = async (req, res) => {
  const { paymentMethod, discountType, discountValue } = req.body;
  const order = await svcCheckout(
    req.params.id,
    { paymentMethod, discountType, discountValue },
    req.user._id
  );
  res.json({ order });
};

// ─── Cancel ───────────────────────────────────────────────────────────────────

export const cancelOrder = async (req, res) => {
  const { note } = req.body;
  const order = await transitionStatus(req.params.id, 'cancelled', req.user._id, note || 'Cancelled');
  res.json({ order });
};

// ─── KDS: item-level status ───────────────────────────────────────────────────

export const updateItemStatus = async (req, res) => {
  const { itemId } = req.params;
  const { status } = req.body;
  const order = await svcUpdateItemStatus(req.params.id, itemId, status, req.user._id);
  res.json({ order });
};
